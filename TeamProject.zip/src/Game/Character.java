package Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

/**
 * Created by Admin on 4/19/2016.
 */
public class Character {


    Image Character;

    ImageIcon pFacingLeft = new ImageIcon("resources/m1.png");
    ImageIcon pFacingRight = new ImageIcon("resources/m2.png");
    public int dx;
    public int dy;
    private int x;
    private int y;
    public int width;
    public int height;


    public boolean visible;


    public Character()

    {

        Character = new ImageIcon(String.valueOf(pFacingLeft)).getImage();
        Character = new ImageIcon(String.valueOf(pFacingRight)).getImage();


        width = Character.getWidth(null);

        height = Character.getHeight(null);


        visible = true;


        x = 100;

        y = 285;


    }


    public void move()

    {

        x += dx;


        y += dy;


        if (x < 0)

            x = 1;


    }


    public int getX()

    {

        return x;

    }


    public int getY()

    {

        return y;

    }


    public Image getImage()

    {

        return Character;

    }


    public void keyPressed(KeyEvent e)

    {

        int key = e.getKeyCode();


        if (key == KeyEvent.VK_RIGHT)

            dx = 1;


        if (key == KeyEvent.VK_LEFT)

            dx = -1;


        if (key == KeyEvent.VK_SPACE)

        {
            int jump = 20;


            dy = -jump;


        }


    }


    public void keyReleased(KeyEvent e)

    {

        int key = e.getKeyCode();


        if (key == KeyEvent.VK_RIGHT)

            dx = 0;

        if (key == KeyEvent.VK_LEFT)

            dx = 0;
        if (key == KeyEvent.VK_SPACE) {
            dy = 0 ;
        }
    }
}




