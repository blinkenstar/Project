package Game;

/**
 * Created by Admin on 4/8/2016.
 */
public class Launcher {
    public static void main(String[] args) {
        Game game = new Game ("Workshop",800,600);
        game.start();
    }
}
