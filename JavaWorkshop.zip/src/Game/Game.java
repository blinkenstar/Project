package Game;

import Display.Display;
import gfx.ImageLoader;

import java.awt.*;
import java.awt.image.BufferStrategy;

/**
 * Created by Admin on 4/8/2016.
 */
public class Game implements Runnable {
    private String name;
    private int width, height;

    private Thread thread;
    private boolean isRunning;

    private Display display;
    private BufferStrategy bs;
    private Graphics g;

    public Game(String name, int width, int height) {
        this.name = name;
        this.width = width;
        this.height = height;

    }

    public void init() {

        this.display = new Display(this.name, this.width, this.height);
        this.g = this.display.getCanvas().getGraphics();
    }

    public void tick() {
    }

    public void render() {
        this.bs = this.display.getCanvas().getBufferStrategy();
        if (this.bs == null) {

            this.display.getCanvas().createBufferStrategy(2);
            this.bs = this.display.getCanvas().getBufferStrategy();
        }
        this.g = this.bs.getDrawGraphics();
        this.g.clearRect(0, 0, this.width, this.height);
        //START DRAWING

       this.g.drawImage(ImageLoader.loadImage("/zombie_bunny_.jpg"), 0, 0, 800, 600, null);

        //

        //this.g.setColor(Color.magenta);

        //this.g.fillRect(200, 200, 100, 50);

        //

        this.g.dispose();
        this.bs.show();

    }

    @Override
    public void run() {
        this.init();

        while (isRunning) {
            tick();
            render();
        }
        this.stop();
    }

    public synchronized void start() {
        this.isRunning = true;
        thread = new Thread(this);
        thread.start();
    }


    public synchronized void stop() {
        try {
            this.isRunning = false;
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

