package Display;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Admin on 4/8/2016.
 */
public class Display {

    private JFrame frame;
    private Canvas canvas;

    public Display(String name, int width, int height) {
        this.frame = new JFrame(name);
        this.frame.setPreferredSize(new Dimension(width, height));
        this.frame.setMaximumSize(new Dimension(width, height));
        this.frame.setMaximumSize(new Dimension(width, height));
        this.frame.setVisible(true);
        this.frame.setFocusable(true);
        this.frame.setResizable(false);
        this.frame.setLocationRelativeTo(null);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        this.canvas = new Canvas();
        this.canvas.setPreferredSize(new Dimension(width, height));
        this.canvas.setMaximumSize(new Dimension(width, height));
        this.canvas.setMaximumSize(new Dimension(width, height));
        this.canvas.setFocusable(true);


        this.frame.add(this.canvas);
        this.frame.pack();

    }


    public Canvas getCanvas() {
        return canvas;
    }
}
